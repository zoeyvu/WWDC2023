import SwiftUI

struct MasterView: View {
    
    @StateObject var flock: Flock
    
    @EnvironmentObject var screen: Screen
    
    @State var separateValue: CGFloat
    @State var alignValue: CGFloat
    @State var cohereValue: CGFloat
    @State var avoidValue: CGFloat
    
    @State var showCohere = true
    @State var showSeparate = false
    @State var showAlign = false
    @State var showAvoid = false
    @State var enableTeam = false
    @State var separateBig = false
    @State var enableNext = false
    
    
    
    init() {
        let flockWidth = CGFloat(500)     //screenSize.width
        let flockHeight = CGFloat(800)   //screenSize.height
        let cutOffValues = CutOffValues()
        
        cutOffValues.separate = CGFloat(0)
        cutOffValues.avoid = CGFloat(3000)
        cutOffValues.cohere = CGFloat(0)
        cutOffValues.align = CGFloat(0)
        cutOffValues.numBirds = 200
        cutOffValues.wrap = false
        
        let flock = Flock(width: flockWidth, height: flockHeight, cutOffValues: cutOffValues)
        
        _flock = StateObject(wrappedValue: flock)
        _separateValue = State(wrappedValue: cutOffValues.separate)
        _alignValue = State(wrappedValue: cutOffValues.align)
        _cohereValue = State(wrappedValue: cutOffValues.cohere)
        _avoidValue = State(wrappedValue: cutOffValues.avoid)
    }
    
    var body: some View {
        //NavigationView {
        HStack {
            ZStack {
                ForEach(flock.boids) { boid in
                    Triangle()
                        .rotation(.radians(boid.velocity.heading + (.pi / 2)))
                        .fill(flock.teamMode ? boid.color : .black)
                        .frame(width: 8, height: 16)
                        .position(boid.position)
                }
                Circle()
                    .fill(Color.blue)
                    .frame(width: 25, height: 25)
                    .position(flock.obstacle)
                    .gesture(
                        DragGesture(minimumDistance: 10)
                            .onChanged { value in
                                flock.obstacle = value.location
                            }
                    )
                
            }
            .frame(width: flock.width, height: flock.height)
            .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.05), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom))
            .background(Color.white)
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        flock.cutOffValues.followPoint = value.location
                    }
                    .onEnded { value in
                        flock.cutOffValues.followPoint = nil
                    }
            )
            .ignoresSafeArea()
            
            ///////////////
                VStack {
                    Text("Let's incorporate all of what we have learned about boids together")
                        .comment()
                        .padding()

                    VStack {
                        Text("Click and hold the screen to attract birds")
                            .hint()
                        Text("Drag and drop to blue circle obstacle to change its position")
                            .hint()
                    }
                    .frame(width: 400)
                    Spacer()
                        .frame(height: 50)
                    
                    // Sliders
                    
                    VStack {
                        
                        HStack {
                            Text("Coherence: \(cohereValue, specifier: "%.0f")")
                                .frame(width: 170, alignment: .topLeading)
                            Slider(value: $cohereValue, in: 0...5000, step: 1.0)
                                .onChange(of: cohereValue) { newValue in
                                    flock.cutOffValues.cohere = newValue
                                    if newValue > 4500 {
                                        showSeparate = true
                                    }
                                }
                            }
                        Spacer()
                            .frame(height: 25)
                        
                            HStack {
                                Text("Seperation: \(separateValue, specifier: "%.0f")")
                                    .frame(width: 170, alignment: .topLeading)
                                Slider(value: $separateValue, in: 0...5000, step: 1.0)
                                    .onChange(of: separateValue) { newValue in
                                        flock.cutOffValues.separate = newValue
                                        if (!separateBig && newValue > 4500) {
                                            separateBig = true
                                        }
                                        if separateBig && newValue < 500 {
                                            showAlign = true
                                        }
                                    }
                            }
                        Spacer()
                            .frame(height: 25)
                            HStack {
                                Text("Alignment: \(alignValue, specifier: "%.0f")")
                                    .frame(width: 170, alignment: .topLeading)
                                Slider(value: $alignValue, in: 0...5000, step: 1.0)
                                    .onChange(of: alignValue) { newValue in
                                        flock.cutOffValues.align = newValue
                                        if newValue > 200 {
                                            enableTeam = true
                                        }
                                    }
                            }
                        Spacer()
                            .frame(height: 25)
                        
                            VStack {
                                Toggle("Team mode", isOn: $flock.teamMode)
                                    .onChange(of: flock.teamMode) { _ in
                                        enableNext = true
                                    }
                                Spacer()
                                    .frame(height: 25)
                                Toggle("Infinite mode", isOn: $flock.cutOffValues.wrap)
                                    .foregroundColor(.black)
                            }
                        Spacer()
                            .frame(height: 100)
                            Text("Next")
                                .padding(10)
                                .font(.system(size: 22, design: .rounded))
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .onTapGesture {
                                    self.flock.boids = []
                                    screen.num += 1
                                }
                    }
                    .frame(width: 350, height: 400)
                }
                .frame(width: 500, height: 800)
                .background(Color.white)
                .foregroundColor(.black)
                .font(.system(size: 20))
        }
    }
    
}




struct MasterView_Previews: PreviewProvider {
    static var previews: some View {
        MasterView()
    }
}
