import SwiftUI

struct IntroView: View {
    
    @StateObject var flock: Flock
    
    @EnvironmentObject var screen: Screen
    
    @State var separateValue: CGFloat
    @State var alignValue: CGFloat
    @State var cohereValue: CGFloat
    @State var avoidValue: CGFloat
    
    @State var showCohere = true
    @State var showSeparate = false
    @State var showAlign = false
    @State var showAvoid = false
    @State var enableTeam = false
    @State var separateBig = false
    @State var enableNext = false
    
    
    
    init() {
        let flockWidth = CGFloat(500)     //screenSize.width
        let flockHeight = CGFloat(800)   //screenSize.height
        let cutOffValues = CutOffValues()
        
        cutOffValues.separate = CGFloat(0)
        cutOffValues.avoid = CGFloat(0)
        cutOffValues.cohere = CGFloat(0)
        cutOffValues.align = CGFloat(0)
        cutOffValues.numBirds = 0
        cutOffValues.wrap = false
        
        let flock = Flock(width: flockWidth, height: flockHeight, cutOffValues: cutOffValues)
        
        _flock = StateObject(wrappedValue: flock)
        _separateValue = State(wrappedValue: cutOffValues.separate)
        _alignValue = State(wrappedValue: cutOffValues.align)
        _cohereValue = State(wrappedValue: cutOffValues.cohere)
        _avoidValue = State(wrappedValue: cutOffValues.avoid)
    }
    
    var body: some View {
        //NavigationView {
            HStack {
                ZStack {
                    ForEach(flock.boids) { boid in
                        Triangle()
                            .rotation(.radians(boid.velocity.heading + (.pi / 2)))
                            .fill(flock.teamMode ? boid.color : .black)
                            .frame(width: 8, height: 16)
                            .position(boid.position)
                    }
                    
                    if flock.boids.count <= 1 {
                        VStack {
                            Spacer()
                                .frame(height: 40)
                                .multilineTextAlignment(.center)
                            Text("↓ First, let's click on the screen to make birds ↓")
                                .padding()
                                .font(.system(size: 20, design: .rounded))
                                .foregroundColor(.teal)
                                .background(Color.white)
                                .cornerRadius(10)
                                .shadow(color: .blue.opacity(0.3), radius: 10, x: 0, y: 0)
                            Spacer()
                                .frame(height: 400)
                        }
                    } else if flock.boids.count < 31 {
                        VStack {
                            Text("keep clicking, we need " + String(31 - flock.boids.count) + " more birds!")
                                .padding()
                                .font(.system(size: 20, design: .rounded))
                                .foregroundColor(.teal)
                                .background(Color.white)
                                .cornerRadius(10)
                                .shadow(color: .blue.opacity(0.3), radius: 10, x: 0, y: 0)
                            Spacer()
                                .frame(height: 450)
                        }
                    }
                    
                    
                }
                .frame(width: flock.width, height: flock.height)
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.05), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom))
                .background(Color.white)
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onEnded { value in
                            if flock.boids.count < 100 {
                                flock.addBoid(at: value.location)
                            }
                            
                        }
                )
                .ignoresSafeArea()
                
                ///////////////
                if flock.boids.count > 30 {
                    VStack {
                        VStack {
                            // Textintructions
                            
                            if showCohere && !showSeparate {
                                VStack {
                                    Text("Great job calling the birds!")
                                        .comment()
                                    Text("We will apply a few rules on them to make them become organized birds in the next few steps.")
                                        .comment()
                                    Text("Change Coherence to MAX")
                                        .instruction()
                                    Text("Drag and drop the slider below")
                                        .hint()
                                }
                            }
                            
                            if showSeparate && !separateBig {
                                VStack {
                                    Text("wait 10 seconds for the impact to take effect")
                                        .hint()
                                    Text("Coherence makes the birds to fly toward the other birds and gather in groups very closely")
                                        .comment()
                                    Text("Let's tell them to respect social distance with Seperation rule")
                                        .comment()
                                    Text("Change Separation to MAX")
                                        .instruction()
                                }
                            }
                            if showSeparate && separateBig && !showAlign {
                                VStack {
                                    Text("Seperation decides the social distance the birds feel comfortable with.")
                                        .comment()
                                    Text("Right now, the distance is too big, so the birds spread out all over the screen. Let's reduce the distance.")
                                        .comment()
                                    Text("Change Separation to 100")
                                        .instruction()
                                    Text("100 to 500 is best value for Separation")
                                        .hint()
                                }
                            }
                            if showAlign && !enableTeam {
                                VStack {
                                    Text("Awesome! Now the birds are flying toward eachother while keeping a safe distance.")
                                        .comment()
                                    Text("Right now, the groups of bird are flying without direction. Let's change that.")
                                        .comment()
                                    Text("Change Alignment to MAX")
                                        .instruction()
                                }
                            }
                            
                            if enableTeam && !enableNext {
                                VStack {
                                    Text("Alignment makes the birds fly in the same direction as the fellows nearby.")
                                        .comment()
                                    Text("Congratulation! You have just succesfully simulate the flocking of birds!")
                                        .comment()
                                    Text("Let's spice it up a bit by dividing them into teams")
                                        .comment()
                                    Text("Change 'Team mode'")
                                        .instruction()
                                }
                            }
                            if enableNext {
                                Text("wait 10 seconds for the impact to take effect")
                                    .hint()
                                Text("If you wait long enough, the birds will only fly in group of the same color!")
                                    .comment()
                                Text("Click the 'next' button below when you are ready")
                                    .instruction()
                            }
                            
                        }
                        .frame(height: 400)
                        .padding()
                        
                        
                        
                        // Sliders
                        if !enableNext {
                            Divider()
                                .frame(width: 400)
                        }
                        
                        
                        VStack {
                            
                            if showCohere {
                                VStack {
                                    Slider(value: $cohereValue, in: 0...5000, step: 1.0)
                                        .onChange(of: cohereValue) { newValue in
                                            flock.cutOffValues.cohere = newValue
                                            if newValue > 4500 {
                                                showSeparate = true
                                            }
                                        }
                                    Text("Coherence: \(cohereValue, specifier: "%.0f")")
                                }
                            }
                            
                            if showSeparate {
                                VStack {
                                    Slider(value: $separateValue, in: 0...5000, step: 1.0)
                                        .onChange(of: separateValue) { newValue in
                                            flock.cutOffValues.separate = newValue
                                            if (!separateBig && newValue > 4500) {
                                                separateBig = true
                                            }
                                            if separateBig && newValue < 500 {
                                                showAlign = true
                                            }
                                        }
                                    Text("Separation: \(separateValue, specifier: "%.0f")")
                                }
                            }
                            if showAlign {
                                VStack {
                                    Slider(value: $alignValue, in: 0...3000, step: 1.0)
                                        .onChange(of: alignValue) { newValue in
                                            flock.cutOffValues.align = newValue
                                            if newValue > 200 {
                                                enableTeam = true
                                            }
                                        }
                                    Text("Alignment: \(alignValue, specifier: "%.0f")")
                                }
                            }
                            
                            if enableTeam {
                                VStack {
                                    Toggle("Team mode", isOn: $flock.teamMode)
                                        .onChange(of: flock.teamMode) { _ in
                                            enableNext = true
                                        }
                                }
                            }
                            Spacer()
                                .frame(height: 30)
                            if enableNext {
                                Text("Next")
                                    .padding(10)
                                    .font(.system(size: 22, design: .rounded))
                                    .background(Color.orange)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .onTapGesture {
                                        self.flock.boids = []
                                        screen.num += 1
                                    }
                            }
                        }
                        .frame(width: 199, height: showAvoid ? 250 : 300)
                        
                    }
                    .frame(width: 500, height: 800)
                    .background(Color.white)
                    .foregroundColor(.black)
                }
            }
    }

}




struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
