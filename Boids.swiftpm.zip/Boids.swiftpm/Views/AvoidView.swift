import SwiftUI

struct AvoidView: View {
    
    @EnvironmentObject var screen: Screen
    
    @StateObject var flock: Flock
    
    @State var separateValue: CGFloat
    @State var alignValue: CGFloat
    @State var cohereValue: CGFloat
    @State var avoidValue: CGFloat
    
    init() {
        let flockWidth = CGFloat(500)     //screenSize.width
        let flockHeight = CGFloat(800)   //screenSize.height
        let cutOffValues = CutOffValues()
        
        cutOffValues.avoid = CGFloat(3000)
        
        let flock = Flock(width: flockWidth, height: flockHeight, cutOffValues: cutOffValues, maxSpeed: CGFloat(10))
                
        _flock = StateObject(wrappedValue: flock)
        _separateValue = State(wrappedValue: cutOffValues.separate)
        _alignValue = State(wrappedValue: cutOffValues.align)
        _cohereValue = State(wrappedValue: cutOffValues.cohere)
        _avoidValue = State(wrappedValue: cutOffValues.avoid)
    }
    
    
    var body: some View {
        
        
        HStack {
            ZStack {
                ForEach(flock.boids) { boid in
                    Triangle()
                        .rotation(.radians(boid.velocity.heading + (.pi / 2)))
                        .fill(flock.teamMode ? boid.color : .black)
                        .frame(width: 8, height: 16)
                        .position(boid.position)
                    
                        Circle()
                            .fill(Color.blue)
                            .frame(width: 25, height: 25)
                            .position(flock.obstacle)
                }
            }
//            .background(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.15), Color.pink.opacity(0.15), Color.orange.opacity(0.15), Color.red.opacity(0.15)]), startPoint: .top, endPoint: .bottom))
            .background(LinearGradient(gradient: Gradient(colors: [Color.orange.opacity(0.15), Color.mint.opacity(0.15)]), startPoint: .topTrailing, endPoint: .bottomLeading))
            .background(Color.white)
            .frame(width: flock.width, height: flock.height)
            .gesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { value in
                        flock.obstacle = value.location
                    }
            )
            .ignoresSafeArea()
            
            VStack {
                Text("Now, let's try to chase the birds away")
                    .comment()
                Text("Drag and drop the blue circle to chase the birds away")
                    .instruction()
                Spacer()
                    .frame(height: 50)
                
                Divider()
                    .frame(width: 400)
                Spacer()
                    .frame(height:50)
                Text("Infinite mode allows the birds to fly pass the edge screen")
                    .hint()
                Spacer()
                    .frame(height:50)
                
                Toggle("Infinite mode", isOn: $flock.cutOffValues.wrap)
                    .frame(width: 200)
                    .foregroundColor(.black)
                
                Spacer()
                    .frame(height: 100)

                Text("Next")
                    .padding(10)
                    .font(.system(size: 22, design: .rounded))
                    .background(Color.orange)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .onTapGesture {
                        screen.num += 1
                    }

            }
            .frame(width: 500, height: 800)
            .background(Color.white)
            .foregroundColor(.black)
            
        }
        
    }
}

struct AvoidView_Previews: PreviewProvider {
    static var previews: some View {
        AvoidView()
    }
}
