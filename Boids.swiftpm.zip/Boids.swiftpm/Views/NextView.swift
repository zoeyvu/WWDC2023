import SwiftUI

struct NextView: View {
    
    @EnvironmentObject var screen: Screen
    
    var body: some View {
        VStack {
            Text("The end")
                .font(.system(size: 70, design: .rounded))
                .bold()
            Text("Hope you had fun with the birds and learned something cool today")
                .frame(width: 300, alignment: .center)
                .font(.system(size: 20))
                .multilineTextAlignment(.center)
            Spacer()
                .frame(height: 300)
            Text("back to start page")
                .padding()
                .font(.system(size: 20))
                .foregroundColor(.white)
                .frame(width: 200, height: 35)
                .background(Color.indigo)
                .cornerRadius(10)
        }
        .frame(width: 500, height: 800)
        .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.05), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom))
        .background(Color.white)
        .foregroundColor(.black)
        .onTapGesture {
            screen.num = 1
        }
        

    }
}

struct NextView_Previews: PreviewProvider {
    static var previews: some View {
        NextView()
            
    }
}
