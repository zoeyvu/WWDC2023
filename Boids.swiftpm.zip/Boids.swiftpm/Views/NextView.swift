import SwiftUI

struct NextView: View {
    
    @EnvironmentObject var screen: Screen
    
    var body: some View {
        VStack {
            Text("The end")
                .font(.system(size: 70, design: .rounded))
                .bold()
                .foregroundColor(.white)
                .shadow(color: .teal, radius: 10, x: 2, y: -2)
            Text("Hope you had fun with the birds and learned something cool today")
                .frame(width: 300, alignment: .center)
                .font(.system(size: 20))
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .shadow(color: .gray, radius: 7, x: 0, y: 0)
            Spacer()
                .frame(height: 100)
            Text("back to start page")
                .padding()
                .font(.system(size: 20, design: .rounded))
                .foregroundColor(.cyan)
                .frame(width: 200, height: 35)
                .background(Color.white)
                .cornerRadius(10)
                .shadow(color: .cyan, radius: 10, x: 0, y: 0)
        }
        .frame(width: 500, height: 800)
        .background(LinearGradient(gradient: Gradient(colors: [Color.indigo.opacity(0.2), Color.mint.opacity(0.2), Color.yellow.opacity(0.3)]), startPoint: .bottomTrailing, endPoint: .topLeading))
        .background(Color.white)
        .foregroundColor(.black)
        .onTapGesture {
            screen.num = 1
        }
        

    }
}

struct NextView_Previews: PreviewProvider {
    static var previews: some View {
        NextView()
            .environmentObject(Screen())
            
    }
}
