import SwiftUI

struct WelcomeView: View {
    
    @State private var welcomeViewOpacity: Double = 1.0
    @EnvironmentObject var screen: Screen
    
    init() {
        UINavigationBar.setAnimationsEnabled(false)
    }
    
    var body: some View {
        //NavigationView {
        VStack {
            VStack {
                Spacer()
                    .frame(height: 50)
                ZStack {
                    BoidsPreView()
                    VStack {
                        Text("Birds of \n a Feather")
                            .font(.system(size: 70, design: .rounded))
                            .bold()
                            .foregroundColor(.white)
                            .shadow(color: .teal, radius: 10, x: 5, y: -2)
                        Spacer()
                            .frame(height: 20)
                        Text("tap to start")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                            .frame(width: 170, height: 35)
                            .background(Color.orange)
                            .cornerRadius(10)
                        Spacer()
                            .frame(height: 4)
                    }
                }
            }
            .onTapGesture {
                screen.num += 1
            }
        }
        //.navigationViewStyle(.stack)
        .frame(width: 800, height: 800, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
    }
    
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}



struct BoidsPreView: View {
    @StateObject var flock: Flock
    
    @State var separateValue: CGFloat
    @State var alignValue: CGFloat
    @State var cohereValue: CGFloat
    @State var avoidValue: CGFloat
    
    init() {
        let flockWidth = CGFloat(500)     //screenSize.width
        let flockHeight = CGFloat(800)   //screenSize.height
        let cutOffValues = CutOffValues()
        
        cutOffValues.separate = CGFloat(100)
        cutOffValues.avoid = CGFloat(0)
        cutOffValues.cohere = CGFloat(1000)
        cutOffValues.align = CGFloat(1000)
        cutOffValues.numBirds = 70
        
        let flock = Flock(width: flockWidth, height: flockHeight, cutOffValues: cutOffValues)
        
        _flock = StateObject(wrappedValue: flock)
        _separateValue = State(wrappedValue: cutOffValues.separate)
        _alignValue = State(wrappedValue: cutOffValues.align)
        _cohereValue = State(wrappedValue: cutOffValues.cohere)
        _avoidValue = State(wrappedValue: cutOffValues.avoid)
    }
    
    var body: some View {
        
        HStack {
            ZStack {
                ForEach(flock.boids) { boid in
                    Triangle()
                        .rotation(.radians(boid.velocity.heading + (.pi / 2)))
                        .fill(flock.teamMode ? boid.color : .black)
                        .frame(width: 6, height: 12)
                        .position(boid.position)
                }
                
            }
            .background(LinearGradient(gradient: Gradient(colors: [Color.indigo.opacity(0.2), Color.mint.opacity(0.2), Color.yellow.opacity(0.3)]), startPoint: .bottomTrailing, endPoint: .topLeading))
            .background(Color.white)
            .frame(width: flock.width, height: flock.height)
            .ignoresSafeArea()
            
        }
        
    }
}

struct BoidsPreView_Previews: PreviewProvider {
    static var previews: some View {
        BoidsPreView()
            .environmentObject(CutOffValues())
    }
}
