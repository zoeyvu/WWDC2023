import SwiftUI


struct ContentView: View {
    let screenSize = UIScreen.main.bounds.size
    //@StateObject var cutOffValues = CutOffValues()
    @StateObject var flock: Flock
    
    @State var separateValue: CGFloat
    @State var alignValue: CGFloat
    @State var cohereValue: CGFloat
    @State var avoidValue: CGFloat

    init() {
        let flockWidth = CGFloat(500)     //screenSize.width
        let flockHeight = CGFloat(800)   //screenSize.height
        let cutOffValues = CutOffValues()
        let flock = Flock(width: flockWidth, height: flockHeight, cutOffValues: cutOffValues)
        _flock = StateObject(wrappedValue: flock)
        _separateValue = State(wrappedValue: cutOffValues.separate)
        _alignValue = State(wrappedValue: cutOffValues.align)
        _cohereValue = State(wrappedValue: cutOffValues.cohere)
        _avoidValue = State(wrappedValue: cutOffValues.avoid)
    }

    var body: some View {

        HStack {
            ZStack {
                ForEach(flock.boids) { boid in
                    Triangle()
                    .rotation(.radians(boid.velocity.heading + (.pi / 2)))
                    .fill(flock.teamMode ? boid.color : .green)
                    .frame(width: 7, height: 14)
                    .position(boid.position)
                }
                
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 25, height: 25)
                        .position(flock.obstacle)

            }
            .background(Color(white:0.2, opacity: 1))
            .frame(width: flock.width, height: flock.height)
            .ignoresSafeArea()
            .gesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { value in
                        flock.obstacle = value.location
                    }
            )
            .onTapGesture {
                flock.teamMode.toggle()
            }


            VStack {
                VStack {
                    Slider(value: $separateValue, in: 0...5000, step: 1.0)
                        .onChange(of: separateValue) { newValue in
                                flock.cutOffValues.separate = newValue
                            }
                    Text("Separate: \(separateValue, specifier: "%.0f")")
                }
                VStack {
                    Slider(value: $alignValue, in: 0...5000, step: 1.0)
                        .onChange(of: alignValue) { newValue in
                                flock.cutOffValues.align = newValue
                            }
                    Text("Align: \(alignValue, specifier: "%.0f")")
                }
                VStack {
                    Slider(value: $cohereValue, in: 0...5000, step: 1.0)
                        .onChange(of: cohereValue) { newValue in
                                flock.cutOffValues.cohere = newValue
                            }
                    Text("Cohere: \(cohereValue, specifier: "%.0f")")
                }

            }
            .frame(width: 300)
            
        }

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(CutOffValues())
    }
}
