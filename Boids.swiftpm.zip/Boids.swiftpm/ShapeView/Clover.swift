import SwiftUI

struct Clover: Shape {
    func path(in rect: CGRect) -> Path {
        let radius = min(rect.width, rect.height) / 2
        let center = CGPoint(x: rect.midX, y: rect.midY)
        
        var path = Path()
        
        for index in 0..<4 {
            let angle = CGFloat(index) * CGFloat.pi / 2
            let circleCenter = CGPoint(x: center.x + cos(angle) * radius / 2, y: center.y + sin(angle) * radius / 2)
            path.addArc(center: circleCenter, radius: radius / 2, startAngle: .zero, endAngle: .degrees(360), clockwise: false)
        }
        
        return path
    }
}
