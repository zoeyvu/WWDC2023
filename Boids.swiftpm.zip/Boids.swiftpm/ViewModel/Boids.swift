import SwiftUI

class Boid: Identifiable {
    let id = UUID()
    let color: Color = [.purple, .orange, .pink, .indigo].randomElement()! // teams update
    
    var position: CGPoint
    var velocity: CGPoint
    var maximumSpeed: CGFloat
    
    var cutOffValues: CutOffValues
    
    init(x: CGFloat, y: CGFloat, cutOffValues: CutOffValues, maxSpeed: CGFloat = 10) {
        position = CGPoint(x: x, y: y)
        
        let angle = Double.random(in: 0...(.pi * 2))
        velocity = CGPoint(x: cos(angle), y: sin(angle))
        self.cutOffValues = cutOffValues
        self.maximumSpeed = maxSpeed
    }
    
    func run(in flock: Flock) {
        velocity += calculateAcceleration(with: flock)
        velocity.limit(to: maximumSpeed)
        position += velocity
        
        if cutOffValues.wrap {
            wrap(in: flock)
        } else {
            avoidEdges(in: flock)
        }
    }
    
    private func calculateAcceleration(with flock: Flock) -> CGPoint {
        var acceleration = separate(from: flock) * 3
        acceleration += align(to: flock)
        acceleration += cohere(to: flock)
        acceleration += avoid(flock.obstacle) * 200
        
        if let fposition = cutOffValues.followPoint {
            acceleration += follow(fposition) * 3
        }
        
        
        return acceleration
    }
    
    private func separate(from flock: Flock) -> CGPoint {
        let nearby = neighbours(in: flock, distanceCutOff: cutOffValues.separate)
        
        guard nearby.count > 0 else { return .zero }
        
        var acceleration = nearby.reduce(CGPoint.zero) {
            var difference = position - $1.boid.position
            difference /= $1.distance
            
            return $0 + difference
        }
        
        acceleration /= CGFloat(nearby.count)
        return steer(acceleration)
    }
    
    private func align(to flock: Flock) -> CGPoint {
        let nearby = neighbours(in: flock, distanceCutOff: cutOffValues.align)
        guard nearby.count > 0 else { return .zero }
        
        var acceleration = nearby.reduce(CGPoint.zero) {
            $0 + $1.boid.velocity
        }
        return steer(acceleration)
    }
    
    private func cohere(to flock: Flock) -> CGPoint {
        let nearby = neighbours(in: flock, distanceCutOff: cutOffValues.cohere)
        guard nearby.count > 0 else { return .zero }
        
        var acceleration = nearby.reduce(CGPoint.zero) {
            $0 + $1.boid.position
        }
        
        acceleration /= CGFloat(nearby.count)
        acceleration -= position
        
        return steer(acceleration)
    }
    
    private func follow(_ point: CGPoint) -> CGPoint {
        var acceleration = (point - position).normalized() * maximumSpeed
        return steer(acceleration)
    }
    
    private func avoid(_ obstacle: CGPoint) -> CGPoint {
        let distance = position.distanceSquared(from: obstacle)
        var distanceCutOff = cutOffValues.avoid
        
        guard distance < distanceCutOff else { return .zero }
        
        var acceleration = position - obstacle
        acceleration /= distance
        return steer(acceleration)
    }
    
    private func wrap(in flock: Flock) {
        let boidSize: CGFloat = 0
        
        if position.x < -boidSize {
            position.x = flock.width + boidSize
        } else if position.x > flock.width + boidSize {
            position.x = -boidSize
        }
        
        if position.y < -boidSize {
            position.y = flock.height + boidSize
        } else if position.y > flock.height + boidSize {
            position.y = -boidSize
        }
    }
    
    private func avoidEdges(in flock: Flock) {
        let boidSize: CGFloat = 10
        let rangee: Int = 1
        
        if position.x < boidSize {
            velocity += CGPoint(x: abs(velocity.x), y: -abs(velocity.y)).normalized() * 2
            velocity += CGPoint(x: Int.random(in: -rangee ... rangee), y: 0).normalized()  
        } else if position.x > flock.width - boidSize {
            velocity -= CGPoint(x: abs(velocity.x), y: -abs(velocity.y)).normalized() * 2
            velocity -= CGPoint(x: Int.random(in: -rangee ... rangee), y: 0).normalized() 
        }
        
        if position.y < boidSize {
            velocity += CGPoint(x: -abs(velocity.x), y: abs(velocity.y)).normalized() * 2
            velocity += CGPoint(x: 0, y: Int.random(in: -rangee ... rangee)).normalized() 
        } else if position.y > flock.height - boidSize {
            velocity -= CGPoint(x: -abs(velocity.x), y: abs(velocity.y)).normalized() * 2
            velocity -= CGPoint(x: 0, y: Int.random(in: -rangee ... rangee)).normalized() 
        }
        
        
        position.x = max(min(position.x, flock.width - boidSize), boidSize)
        position.y = max(min(position.y, flock.height - boidSize), boidSize)
        
    }

    
    private func neighbours(in flock: Flock, distanceCutOff: CGFloat) -> [(boid: Boid, distance: CGFloat)] {
        flock.boids.compactMap { other in
            if flock.teamMode == true && self.color != other.color { return nil } // teams mode
            
            let distance = position.distanceSquared(from: other.position)
            
            if distance > 0 && distance < distanceCutOff {
                return (other, distance)
            } else {
                return nil
            }
        }
    }
    
    private func steer(_ acceleration: CGPoint) -> CGPoint {
        var acceleration = acceleration
        acceleration.normalize()
        acceleration *= maximumSpeed
        acceleration -= velocity
        
        let maximumSteer: CGFloat = 0.1
        acceleration.limit(to: maximumSteer)
        return acceleration
    }
    
}

class Flock: ObservableObject {
    
    var cutOffValues: CutOffValues
    
    var displayLink: CADisplayLink?
    
    let width: CGFloat
    let height: CGFloat
    var maxSpeed: CGFloat
    
    @Published var boids = [Boid]()
    var teamMode = false // teams update
    
    var obstacle: CGPoint
    
    init(width: CGFloat = 500, height: CGFloat = 800, cutOffValues: CutOffValues = CutOffValues(), maxSpeed: CGFloat = 7) {
        self.width = width
        self.height = height
        self.cutOffValues = cutOffValues
        self.maxSpeed = maxSpeed
        
        obstacle = CGPoint(x: width / 2, y: height / 2)
        
        for _ in 0..<cutOffValues.numBirds {
            addBoid(at: CGPoint(x: CGFloat.random(in: 0..<width),y:  CGFloat.random(in: 0..<height)))
        }


        
        displayLink = CADisplayLink(target: self, selector: #selector(update))
        displayLink?.add(to: .current, forMode: . default)
    }
    
    @objc func update() {
        objectWillChange.send()
        
        for boid in boids {
            boid.run(in: self)
        }
    }
    
    func addBoid(at point: CGPoint, with speed: CGFloat = 7) {
        let newBoid = Boid(x: point.x, y: point.y, cutOffValues: self.cutOffValues, maxSpeed: speed)
        boids.append(newBoid)
    }
    
}
