import SwiftUI

class CutOffValues: ObservableObject {
    @Published var separate: CGFloat
    @Published var align: CGFloat
    @Published var cohere: CGFloat
    @Published var avoid: CGFloat
    @Published var wrap: Bool
    @Published var numBirds: Int
    @Published var followPoint: CGPoint?
    
    init(separate: CGFloat = 900, align: CGFloat = 3000, cohere: CGFloat = 1800, avoid: CGFloat = 1800, wrap: Bool = true, numBirds: Int = 200) {
        self.separate = separate
        self.align = align
        self.cohere = cohere
        self.avoid = avoid
        self.wrap = wrap
        self.numBirds = numBirds
        self.followPoint = nil
    }
}
