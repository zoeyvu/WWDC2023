import SwiftUI
import AVFoundation

@main
struct BoidsExampleApp: App {
    
    @StateObject var screen = Screen()
    @State var audioPlayer: AVAudioPlayer?
    
    var body: some Scene {
        WindowGroup {
            VStack {
                if screen.num == 1 {
                    WelcomeView()
                } else if screen.num == 2 {
                    IntroView()
                } else if screen.num == 3 {
                    FollowView()
                } else if screen.num == 4 {
                    AvoidView()
                } else if screen.num == 5 {
                    MasterView()
                } else {
                    NextView()
                }
            }
            .environmentObject(screen)
            .foregroundColor(.black)
            .onAppear(perform: {
                playAudio()
            })

        }
    }
    
    func playAudio() { /// function to play audio
        
        /// the URL of the audio file.
        /// forResource = name of the file. 
        /// withExtension = extension, usually "mp3"
        if let audioURL = Bundle.main.url(forResource: "music", withExtension: "mp3") {
            do {
                try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                self.audioPlayer?.numberOfLoops = 10 /// Number of times to loop the audio
                self.audioPlayer?.play() /// start playing
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
}

class Screen: ObservableObject {
    @Published var num = 1
}
