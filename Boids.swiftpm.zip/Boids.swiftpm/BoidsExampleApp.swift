//
//  BoidsExampleApp.swift
//  BoidsExample
//

import SwiftUI

@main
struct BoidsExampleApp: App {
    
    @StateObject var screen = Screen()
    
    var body: some Scene {
        WindowGroup {
            VStack {
                if screen.num == 1 {
                    WelcomeView()
                } else if screen.num == 2 {
                    IntroView()
                } else if screen.num == 3 {
                    FollowView()
                } else if screen.num == 4 {
                    AvoidView()
                } else if screen.num == 5 {
                    MasterView()
                } else {
                    NextView()
                }
            }
            .environmentObject(screen)
            .foregroundColor(.black)

        }
    }
}

class Screen: ObservableObject {
    @Published var num = 1
}
