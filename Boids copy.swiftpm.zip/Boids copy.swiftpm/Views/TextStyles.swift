import SwiftUI


// Text Comment
// Text Intructsion: has shade, is color coded, indent
// Text Hint




struct Comment: ViewModifier {
    func body(content: Content) -> some View {
        HStack {
            content
                .padding(10)
                .font(.system(size: 22, design: .rounded))
                .frame(maxWidth: 400, alignment: .topLeading)
                .foregroundColor(.black)
            
        }
        
    }
}

struct Instruction: ViewModifier {
    func body(content: Content) -> some View {
        VStack {
            Divider()
            Spacer()
                .frame(height: 20)
            Text("Next step: ")
                .font(.system(size: 20, design: .rounded))
                .bold()
            content
                .padding(10)
                .font(.system(size: 18, design: .monospaced))
                .background((Color.orange).opacity(0.1))
                .cornerRadius(5)
        }
        .foregroundColor(.black)
        .frame(maxWidth: 400, alignment: .center)
    }
}

struct Hint: ViewModifier {
    func body(content: Content) -> some View {
        HStack {
            Text("💡Tip:")
                .frame(alignment: .center)
            content
        }
        .padding(10)
        .font(.system(size: 18, design: .rounded))
        .foregroundColor(.black)
        .background((Color.teal).opacity(0.05))
        .cornerRadius(5)
        .frame(maxWidth: 400, alignment: .center)
    }
}

struct Text_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            Text("Great job calling the birds, although they are a bit unorganized")
                .comment()
            Text("Let's change Align to MAX")
                .instruction()
            Text("try Seperate=MIN, Avoid=1000, Cohere=500")
                .hint()
        }
        .frame(width: 300)
        
    }
}


extension View {
    func comment() -> some View {
        modifier(Comment())
    }
    
    func instruction() -> some View {
        modifier(Instruction())
    }
    func hint() -> some View {
        modifier(Hint())
    }
}
