import SwiftUI

struct AvoidView: View {
    
    @EnvironmentObject var screen: Screen
    
    @StateObject var flock: Flock
    
    @State var separateValue: CGFloat
    @State var alignValue: CGFloat
    @State var cohereValue: CGFloat
    @State var avoidValue: CGFloat
    
    init() {
        let flockWidth = CGFloat(500)     //screenSize.width
        let flockHeight = CGFloat(700)   //screenSize.height
        let cutOffValues = CutOffValues()
        cutOffValues.numBirds = 150
        
        cutOffValues.separate = CGFloat(300)
        cutOffValues.avoid = CGFloat(3000)
        cutOffValues.cohere = CGFloat(1500)
        cutOffValues.align = CGFloat(2000)
        cutOffValues.wrap = false
        
        let flock = Flock(width: flockWidth, height: flockHeight, cutOffValues: cutOffValues, maxSpeed: CGFloat(10))
        
        _flock = StateObject(wrappedValue: flock)
        _separateValue = State(wrappedValue: cutOffValues.separate)
        _alignValue = State(wrappedValue: cutOffValues.align)
        _cohereValue = State(wrappedValue: cutOffValues.cohere)
        _avoidValue = State(wrappedValue: cutOffValues.avoid)
    }
    
    var body: some View {
        
        HStack {
            ZStack {
                ForEach(flock.boids) { boid in
                    Triangle()
                        .rotation(.radians(boid.velocity.heading + (.pi / 2)))
                        .fill(flock.teamMode ? boid.color : .black)
                        .frame(width: 8, height: 16)
                        .position(boid.position)
                    
                        Circle()
                            .fill(Color.blue)
                            .frame(width: 25, height: 25)
                            .position(flock.obstacle)
                }
            }
            .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.05), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom))
            .background(Color.white)
            .frame(width: flock.width, height: flock.height)
            .gesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { value in
                        flock.obstacle = value.location
                    }
            )
            .ignoresSafeArea()
            
            VStack {
                Spacer()
                    .frame(height: 50)
                Text("Drag and drop the blue circle to chase the bird away")
                    .instruction()
                Spacer()
                    .frame(height: 50)
                Divider()
                Spacer()
                    .frame(height:50)
                
                Toggle("Team mode", isOn: $flock.teamMode)
                    .frame(width: 200)
                
                Spacer()
                    .frame(height: 100)

                Text("Next")
                    .padding(10)
                    .font(.system(size: 22, design: .rounded))
                    .background(Color.orange)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .onTapGesture {
                        screen.num += 1
                    }

            }
            .frame(width: 300, height: 700)
            .background(Color.white)
            
        }
        
    }
}

struct AvoidView_Previews: PreviewProvider {
    static var previews: some View {
        AvoidView()
    }
}
