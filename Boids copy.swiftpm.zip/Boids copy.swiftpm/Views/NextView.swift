import SwiftUI

struct NextView: View {
    
    var body: some View {
        VStack {
            Text("That is it for now")
            Text("Thanks youuu!")
        }
        .frame(width: 500, height: 700)
        .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.05), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom))
        .background(Color.white)
        

    }
}

struct NextView_Previews: PreviewProvider {
    static var previews: some View {
        NextView()
            
    }
}
