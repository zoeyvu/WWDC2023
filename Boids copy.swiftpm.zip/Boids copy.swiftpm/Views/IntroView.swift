import SwiftUI

struct IntroView: View {
    
    @StateObject var flock: Flock
    
    @EnvironmentObject var screen: Screen
    
    @State var separateValue: CGFloat
    @State var alignValue: CGFloat
    @State var cohereValue: CGFloat
    @State var avoidValue: CGFloat
    
    @State var showCohere = true
    @State var showSeparate = false
    @State var showAlign = false
    @State var showAvoid = false
    @State var enableTeam = false
    @State var separateBig = false
    @State var enableNext = false
    
    
    
    init() {
        let flockWidth = CGFloat(500)     //screenSize.width
        let flockHeight = CGFloat(700)   //screenSize.height
        let cutOffValues = CutOffValues()
        
        cutOffValues.separate = CGFloat(0)
        cutOffValues.avoid = CGFloat(0)
        cutOffValues.cohere = CGFloat(0)
        cutOffValues.align = CGFloat(0)
        cutOffValues.numBirds = 0
        cutOffValues.wrap = false
        
        let flock = Flock(width: flockWidth, height: flockHeight, cutOffValues: cutOffValues)
        
        _flock = StateObject(wrappedValue: flock)
        _separateValue = State(wrappedValue: cutOffValues.separate)
        _alignValue = State(wrappedValue: cutOffValues.align)
        _cohereValue = State(wrappedValue: cutOffValues.cohere)
        _avoidValue = State(wrappedValue: cutOffValues.avoid)
    }
    
    var body: some View {
        //NavigationView {
            HStack {
                ZStack {
                    ForEach(flock.boids) { boid in
                        Triangle()
                            .rotation(.radians(boid.velocity.heading + (.pi / 2)))
                            .fill(flock.teamMode ? boid.color : .black)
                            .frame(width: 8, height: 16)
                            .position(boid.position)
                    }
                    
                    if flock.boids.count <= 1 {
                        VStack {
                            Text("Today, we are learning")
                                .foregroundColor(.black)
                                .font(.system(size: 30, design: .rounded))
                                .bold()
                            Text("about the flocking of birds")
                                .foregroundColor(.black)
                                .font(.system(size: 30, design: .rounded))
                                .bold()
                            Spacer()
                                .frame(height: 40)
                                .multilineTextAlignment(.center)
                            Text("↓ Click on the screen to make birds ↓")
                                .foregroundColor(.black)
                                .font(.system(size: 20, design: .rounded))
                            Spacer()
                                .frame(height: 400)
                        }
                    } else if flock.boids.count < 30 {
                        VStack {
                            Text("keep clicking, we need more than 30 birds!")
                                .foregroundColor(.black)
                                .font(.system(size: 20, design: .rounded))
                            Spacer()
                                .frame(height: 450)
                        }
                    }
                    
                    
                }
                .frame(width: flock.width, height: flock.height)
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.05), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom))
                .background(Color.white)
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onEnded { value in
                            if flock.boids.count < 100 {
                                flock.addBoid(at: value.location)
                            }
                            
                        }
                )
                .ignoresSafeArea()
                
                ///////////////
                if flock.boids.count > -1 {
                    VStack {
                        VStack {
                            // Textintructions
                            
                            if showCohere && !showSeparate {
                                VStack {
                                    Text("Great job calling the birds, although they are a bit unorganized")
                                        .comment()
                                    Text("Let's change that")
                                        .comment()
                                    Text("Change Cohere to MAX")
                                        .instruction()
                                    Text("Drag and drop the slider below")
                                        .hint()
                                }
                            }
                            
                            if showSeparate && !separateBig {
                                VStack {
                                    Text("Oh they are gathering together now, a bit too close together actually")
                                        .comment()
                                    Text("Let's tell them to respect social distance")
                                        .comment()
                                    Text("Change Separate to MAX")
                                        .instruction()
                                }
                            }
                            if showSeparate && separateBig && !showAlign {
                                VStack {
                                    Text("Oops, too much, maybe a bit less distance")
                                        .comment()
                                    Text("Change Separate to 100")
                                        .instruction()
                                    Text("100 to 500 is best value for Separate")
                                        .hint()
                                }
                            }
                            if showAlign && !enableTeam {
                                VStack {
                                    Text("Awesome, that looks better!")
                                        .comment()
                                    Text("Let's make them fly with a direction")
                                        .comment()
                                    Text("Change Align to MAX")
                                        .instruction()
                                }
                            }
                            
                            if enableTeam && !enableNext {
                                VStack {
                                    Text("Congratulation! You have just succesfully simulate the flocking of birds!")
                                        .comment()
                                    Text("Let's spice it up a bit by dividing them into teams")
                                        .comment()
                                    Text("Change 'Team mode'")
                                        .instruction()
                                }
                            }
                            if enableNext {
                                Text("Feel free to play around with the parameters")
                                    .comment()
                                Text("Click the 'next' button below when you are ready")
                                    .instruction()
                            }
                            
                        }
                        .frame(height: enableNext ? 250 : 350)
                        .padding()
                        
                        
                        
                        // Sliders
                        Divider()
                        
                        VStack {
                            
                            if showCohere {
                                VStack {
                                    Slider(value: $cohereValue, in: 0...5000, step: 1.0)
                                        .onChange(of: cohereValue) { newValue in
                                            flock.cutOffValues.cohere = newValue
                                            if newValue > 4500 {
                                                showSeparate = true
                                            }
                                        }
                                    Text("Cohere: \(cohereValue, specifier: "%.0f")")
                                }
                            }
                            
                            if showSeparate {
                                VStack {
                                    Slider(value: $separateValue, in: 0...5000, step: 1.0)
                                        .onChange(of: separateValue) { newValue in
                                            flock.cutOffValues.separate = newValue
                                            if (!separateBig && newValue > 4500) {
                                                separateBig = true
                                            }
                                            if separateBig && newValue < 500 {
                                                showAlign = true
                                            }
                                        }
                                    Text("Separate: \(separateValue, specifier: "%.0f")")
                                }
                            }
                            if showAlign {
                                VStack {
                                    Slider(value: $alignValue, in: 0...5000, step: 1.0)
                                        .onChange(of: alignValue) { newValue in
                                            flock.cutOffValues.align = newValue
                                            if newValue > 200 {
                                                enableTeam = true
                                            }
                                        }
                                    Text("Align: \(alignValue, specifier: "%.0f")")
                                }
                            }
                            
                            if enableTeam {
                                VStack {
                                    Toggle("Team mode", isOn: $flock.teamMode)
                                        .onChange(of: flock.teamMode) { _ in
                                            enableNext = true
                                        }
                                }
                            }
                            Spacer()
                                .frame(height: 30)
                            if enableNext {
                                Text("Next")
                                    .padding(10)
                                    .font(.system(size: 22, design: .rounded))
                                    .background(Color.orange)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .onTapGesture {
                                        screen.num += 1
                                    }
                            }
                        }
                        .frame(width: 199, height: showAvoid ? 200 : 400)
                        
                    }
                    .frame(width: 300, height: 700)
                    .background(Color.white)
                }
            }
    }

}




struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
