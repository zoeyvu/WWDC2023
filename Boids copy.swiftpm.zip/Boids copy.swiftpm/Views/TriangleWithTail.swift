import SwiftUI

extension Triangle {
    func withTail(tailLength: CGFloat, tailAngle: Double) -> some View {
        ZStack {
            self
                .fill(Color.black)
            Triangle()
                .fill(Color.black)
                .frame(width: tailLength, height: tailLength * 2)
                .rotationEffect(Angle.radians(tailAngle))
                .offset(x: -tailLength / 2, y: -tailLength)
        }
    }
}
