//
//  BoidsExampleApp.swift
//  BoidsExample
//

import SwiftUI

@main
struct BoidsExampleApp: App {
    
    @StateObject var screen = Screen()
    
    var body: some Scene {
        WindowGroup {
            VStack {
                if screen.num == 1 {
                    //ContentView()
                    WelcomeView()
                    //FollowView()
                    //IntroView()
                } else if screen.num == 2 {
                    IntroView()
                } else if screen.num == 3 {
                    FollowView()
                } else if screen.num == 4 {
                    AvoidView()
                } else {
                    NextView()
                }
                
            }
            .environmentObject(screen)
            .foregroundColor(.black)
            
            
            

            //ContentView()
        }
    }
}

class Screen: ObservableObject {
    @Published var num = 1
}
